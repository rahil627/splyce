#include <QApplication>
#include <QtCore>
#include "workbench.h"

int main(int argc, char *argv[])
{   
    QApplication app(argc, argv);
    workbench *myWorkbench = new workbench;
    myWorkbench->show();
    
    return app.exec();
}
